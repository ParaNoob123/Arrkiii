module.exports = {
  name: "playerUpdate",
  run: async (client, player) => {
    // client.logger.log(`Player Has Been Update in`, "log");
  },
};
